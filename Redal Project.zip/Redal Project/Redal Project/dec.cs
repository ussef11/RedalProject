﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Redal_Project
{
    class dec
    {
        public static SqlConnection cnx = new SqlConnection(@"Data Source=HP-PC\SQLEXPRESS;Initial Catalog=redal;Integrated Security=True");
        public static DataSet ds = new DataSet();
        public static SqlDataAdapter da1;

        public dec()
        {
            da1 = new SqlDataAdapter("select Payee from Facture", cnx);
            da1.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            da1.Fill(ds, "fac");
        }
    }
}
