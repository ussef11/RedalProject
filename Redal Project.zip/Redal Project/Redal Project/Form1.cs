﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Redal_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection cnx = new SqlConnection(@"Data Source=HP-PC\SQLEXPRESS;Initial Catalog=redal;Integrated Security=True");
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


        }


        private void textBox1_Enter(object sender, EventArgs e)
        {
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            textBox1.Text += btn.Text;
        }

        string payee = "Non Factures Avaliable";
       
        DataView dv = new DataView(dec.ds.Tables["fac"]);
        private void valid_Click(object sender, EventArgs e)
        {
            cnx.Open();
            SqlCommand cmd = new SqlCommand("select  NumFacture,C.NumClient,Nom,prenom,Montant,Payee,DateExigible from Facture F inner join Client C on F.NumClient = C.NumClient  where F.NumClient = '" + textBox1.Text +"'",cnx);
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;

            cnx.Close();

            cnx.Open();
            SqlCommand cmd1 = new SqlCommand("select Payee ,NumFacture,DateExigible from Facture  where NumClient = '" + textBox1.Text + "'", cnx);
            SqlDataReader dr1 = cmd1.ExecuteReader();
            dr1.Read();


      
            if(dr1.GetValue(0).ToString()== "Oui")
            {
                label3.Visible = false;
                label1.Visible = true;
                label1.Text =  payee.ToString();
                
            }
            else if(dr1.GetValue(0).ToString() == "Non")
            {
                label1.Visible = false;
                label3.Visible = true;
                label3.Text = "Factures Numéro'"+ dr1.GetValue(1).ToString() + "' De La Date '"+ dr1.GetValue(2).ToString() + "' Avaliable" ;
            }
                 
           

            cnx.Close();



            


            

        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
    }
}
